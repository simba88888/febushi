package com.roy;

public class Test {
    public static void main(String[] args) {
        System.out.println(System.getenv("NAMESRV_ADDR"));
    }
}
