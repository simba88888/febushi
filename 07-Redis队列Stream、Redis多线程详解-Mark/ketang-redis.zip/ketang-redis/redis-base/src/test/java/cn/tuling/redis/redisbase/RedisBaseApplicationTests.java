package cn.tuling.redis.redisbase;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RedisBaseApplicationTests {

    @Test
    void contextLoads() {
    }

}
