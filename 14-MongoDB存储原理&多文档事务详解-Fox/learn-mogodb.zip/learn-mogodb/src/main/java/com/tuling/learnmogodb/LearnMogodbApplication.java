package com.tuling.learnmogodb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LearnMogodbApplication {

    public static void main(String[] args) {
        SpringApplication.run(LearnMogodbApplication.class, args);
    }

}
