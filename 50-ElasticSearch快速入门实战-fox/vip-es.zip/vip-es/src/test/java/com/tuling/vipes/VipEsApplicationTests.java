package com.tuling.vipes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VipEsApplicationTests {

//    @Test
//    void contextLoads() {
//    }

}
