package com.tuling.vipes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VipEsApplication {

    public static void main(String[] args) {
        SpringApplication.run(VipEsApplication.class, args);
    }

}
