package com.tuling.zkqueue;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ZkQueueApplication {

    public static void main(String[] args) {
        SpringApplication.run(ZkQueueApplication.class, args);
    }

}
