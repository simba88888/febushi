package com.tuling.zkqueue;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZkQueueApplicationTests {

    @Test
    void contextLoads() {
    }

}
