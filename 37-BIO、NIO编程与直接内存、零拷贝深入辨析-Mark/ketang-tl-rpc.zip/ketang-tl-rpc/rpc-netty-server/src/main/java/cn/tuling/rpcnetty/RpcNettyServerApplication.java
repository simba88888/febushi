package cn.tuling.rpcnetty;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RpcNettyServerApplication {

    public static void main(String[] args) {
        SpringApplication.run(RpcNettyServerApplication.class, args);
    }

}
