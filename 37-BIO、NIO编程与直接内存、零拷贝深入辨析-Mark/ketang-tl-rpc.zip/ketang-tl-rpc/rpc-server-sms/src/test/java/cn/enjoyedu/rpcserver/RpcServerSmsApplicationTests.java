package cn.enjoyedu.rpcserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RpcServerSmsApplicationTests {

    @Test
    void contextLoads() {
    }

}
