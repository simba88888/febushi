package cn.tuling.rpcnetty.rpc.sms;


import org.springframework.stereotype.Service;

/**
 * @author Mark老师
 * 类说明：
 */
@Service
public class NormalBusi {

    public void business(){
        System.out.println("其他的业务操作**************");
    }

}
