/**
 * @author Mark老师
 * 类说明：本包展示了如何使用Netty内置的序列化工具
 */
package cn.tuling.nettybasic.serializable.protobuf;