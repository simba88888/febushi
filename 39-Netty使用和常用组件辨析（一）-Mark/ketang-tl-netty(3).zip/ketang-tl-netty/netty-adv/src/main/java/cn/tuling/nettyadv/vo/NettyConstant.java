package cn.tuling.nettyadv.vo;

/**
 * @author Mark老师
 * 类说明：常量说明
 */
public final class NettyConstant {
    public static final String SERVER_IP = "127.0.0.1";
    public static final int SERVER_PORT = 8989;
}
