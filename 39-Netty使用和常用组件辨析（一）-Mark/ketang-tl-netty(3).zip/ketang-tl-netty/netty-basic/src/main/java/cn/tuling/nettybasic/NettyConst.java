package cn.tuling.nettybasic;

/**
 * @author ：Mark老师
 * @description ：存放常量
 */
public class NettyConst {
    public static final int ECHO_PORT = 9999;

}
