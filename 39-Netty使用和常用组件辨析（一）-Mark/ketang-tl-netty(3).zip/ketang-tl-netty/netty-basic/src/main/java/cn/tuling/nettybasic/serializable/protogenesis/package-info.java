/**
 * @author Mark老师
 * 类说明：Java序列化的缺点，从性能、大小上和我们自定义的序列化机制进行比较
 */
package cn.tuling.nettybasic.serializable.protogenesis;