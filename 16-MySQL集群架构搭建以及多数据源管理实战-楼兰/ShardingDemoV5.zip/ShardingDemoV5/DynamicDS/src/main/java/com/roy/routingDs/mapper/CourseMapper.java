package com.roy.routingDs.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.roy.routingDs.entity.Course;

/**
 * @author roy
 * @desc
 */
public interface CourseMapper extends BaseMapper<Course> {
}
