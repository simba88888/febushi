package com.tuling.lock;

/**
 * @Author Fox
 */
public interface Lock {

   void lock();

   void unlock();
}
