package com.roy.distid;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DistIDApp {
    public static void main(String[] args) {
        SpringApplication.run(DistIDApp.class, args);
    }
}
